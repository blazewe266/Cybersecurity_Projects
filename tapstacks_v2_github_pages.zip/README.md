# TapStacks v2

Simple steps to host on GitHub Pages

1. Create a new public repository on GitHub named `tapstacks` or any name you like.
2. Upload the contents of this folder to the repository root. Make sure `index.html` is at the top level.
   You can drag and drop the files in the GitHub web UI, or push with git from your computer.
3. In your repo, go to Settings → Pages.
4. Under Build and deployment, set Source to Deploy from a branch.
5. Select branch `main` and folder `/root` if your repo uses `main`. Save.
6. Wait up to a minute. Your site will appear at `https://<your-username>.github.io/<repo-name>/`.

Optional custom domain
- In Settings → Pages, set a custom domain, add a DNS CNAME pointing to `<your-username>.github.io`.
- If you know your domain now, create a `CNAME` file in the repo root containing only your domain name.

Notes
- This is a Progressive Web App. Open the URL in Safari on iPhone, tap Share, then Add to Home Screen.
- To enable real payments, paste a Stripe Checkout link in Settings in the app.
- Paste your ad tag in Settings to display real ads.
